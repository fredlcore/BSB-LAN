UIStrings["LANGUAGENAME_TEXT"] = "Portugues";
UIStrings["MENU_TEXT_NO"] = "Não";
UIStrings["MENU_TEXT_YES"] = "Sim";
UIStrings["MENU_TEXT_OFF"] = "Desligado";
UIStrings["MENU_TEXT_ON"] = "Ligado";
UIStrings["MENU_TEXT_OPEN"] = "Aberto";
UIStrings["MENU_TEXT_CLOSE"] = "Fechado";
